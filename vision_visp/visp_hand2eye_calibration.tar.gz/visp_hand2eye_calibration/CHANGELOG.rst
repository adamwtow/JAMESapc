^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package visp_hand2eye_calibration
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.8.1 (2015-04-08)
------------------
* indigo-0.8.0
* Prepare changelogs
* Contributors: Fabien Spindler

0.8.0 (2015-03-31)
------------------
* Merge branch 'indigo-devel' into indigo
* Remove catkin_lint issues and warnings
* Fix doc url location
* indigo-0.7.5
* Prepare changelogs
* Contributors: Fabien Spindler

0.7.5 (2014-08-01)
------------------
* indigo-0.7.4
* Prepare changelogs
* Contributors: Fabien Spindler

0.7.4 (2014-07-03)
------------------
* Update and fix content of README files
* Prepare changelogs
* Contributors: Fabien Spindler

0.7.3 (2014-04-10)
------------------
* indigo-0.7.2
* Prepare changelogs
* Contributors: Fabien Spindler

0.7.2 (2014-04-07)
------------------
* Fix various dependency issues in the CMakeLists.txt and package.xml files
* :lipstick: Aesthetic changes
* Add missing dependency to ViSP
* Fix errors detected with catkin_lint
* Contributors: Fabien Spindler, Thomas Moulard

0.7.0 (2014-03-12)
------------------
* Merge visp_hand2eye_calibration as our subdirectory
* Contributors: Thomas Moulard

